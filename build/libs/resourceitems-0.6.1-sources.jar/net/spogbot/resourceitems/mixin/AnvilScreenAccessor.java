package net.spogbot.resourceitems.mixin;

import net.minecraft.class_342;
import net.minecraft.class_471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_471.class)
public interface AnvilScreenAccessor {
    @Accessor("nameField")
    class_342 getNameField();

    @Invoker("onRenamed")
    void invokeOnRenamed(String name);
}