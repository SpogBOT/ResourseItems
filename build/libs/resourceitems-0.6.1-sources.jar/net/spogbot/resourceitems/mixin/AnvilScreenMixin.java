package net.spogbot.resourceitems.mixin;

import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.spogbot.resourceitems.client.NameSelectionScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_471.class)
public abstract class AnvilScreenMixin extends class_465<class_1706> {
    public AnvilScreenMixin(class_1706 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "setup", at = @At("TAIL"))
    protected void onSetup(CallbackInfo ci) {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("?"), button -> {
                    class_1799 inputStack = this.field_2797.method_7611(0).method_7677();
                    if (!inputStack.method_7960()) {
                        this.field_22787.method_1507(new NameSelectionScreen(this, inputStack));
                    }
                })
                .method_46434(this.field_2776 + 4, this.field_2800 + 45, 20, 20)
                .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43471("gui.desc.see")))
                .method_46431());
    }
}