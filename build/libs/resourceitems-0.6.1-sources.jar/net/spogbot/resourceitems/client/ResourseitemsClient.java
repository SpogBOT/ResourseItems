package net.spogbot.resourceitems.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class ResourseitemsClient implements ClientModInitializer {

    private static final class_5321<class_1761> TAB_KEY = class_5321.method_29179(
            class_7924.field_44688,
            class_2960.method_60655("resourcemodels", "models_tab")
    );

    private static final class_5321<class_1761> RENAMED_TAB_KEY = class_5321.method_29179(
            class_7924.field_44688,
            class_2960.method_60655("resourcemodels", "renamed_models_tab")
    );

    public static final List<class_1799> LOADED_MODELS = new ArrayList<>();
    public static final List<class_1799> LOADED_RENAMED_MODELS = new ArrayList<>();

    private static final Set<class_2960> SEEN_MODELS = new HashSet<>();
    private static final Set<String> SEEN_RENAMED = new HashSet<>();

    @Override
    public void onInitializeClient() {
        class_2378.method_39197(class_7923.field_44687, TAB_KEY, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(class_1802.field_8892))
                .method_47321(class_2561.method_43471("gui.title.items"))
                .method_47317((context, entries) -> {
                    for (class_1799 stack : LOADED_MODELS) {
                        entries.method_45420(stack);
                    }
                })
                .method_47324());

        class_2378.method_39197(class_7923.field_44687, RENAMED_TAB_KEY, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(class_1802.field_8448))
                .method_47321(class_2561.method_43471("gui.title.renames"))
                .method_47317((context, entries) -> {
                    for (class_1799 stack : LOADED_RENAMED_MODELS) {
                        entries.method_45420(stack);
                    }
                })
                .method_47324());

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return class_2960.method_60655("resourcemodels", "model_scanner");
            }

            @Override
            public void method_14491(class_3300 manager) {
                LOADED_MODELS.clear();
                LOADED_RENAMED_MODELS.clear();
                SEEN_MODELS.clear();
                SEEN_RENAMED.clear();

                // Собираем ВСЕ паки, в которых есть хотя бы один items/*.json
                Set<String> packsWithItems = new HashSet<>();
                Map<class_2960, List<class_3298>> allItemsResources = manager.method_41265("items", path -> true);
                for (List<class_3298> resourcesList : allItemsResources.values()) {
                    for (class_3298 res : resourcesList) {
                        packsWithItems.add(res.method_14480());
                    }
                }

                scanAndProcess(manager, "items", packsWithItems);
                scanAndProcess(manager, "models/item", packsWithItems);

                // === ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ ВКЛАДОК ===
                class_310 client = class_310.method_1551();
                if (client != null && client.field_1687 != null && client.field_1724 != null && client.field_1724.field_3944 != null) {
                    class_1761.class_8128 context = new class_1761.class_8128(
                            client.field_1724.field_3944.method_45735(),
                            client.field_1690.method_47395().method_41753(),
                            client.field_1687.method_30349()
                    );

                    class_1761 modelsTab = class_7923.field_44687.method_29107(TAB_KEY);
                    if (modelsTab != null) modelsTab.method_47306(context);

                    class_1761 renamedTab = class_7923.field_44687.method_29107(RENAMED_TAB_KEY);
                    if (renamedTab != null) renamedTab.method_47306(context);
                }
            }

            private void scanAndProcess(class_3300 manager, String startingPath, Set<String> packsWithItems) {
                Map<class_2960, List<class_3298>> resourcesMap = manager.method_41265(
                        startingPath,
                        path -> path.method_12832().endsWith(".json")
                );

                for (Map.Entry<class_2960, List<class_3298>> entry : resourcesMap.entrySet()) {
                    class_2960 resourceId = entry.getKey();
                    String fullPath = resourceId.method_12832();
                    String modelPath = fullPath.substring(0, fullPath.length() - 5);

                    String modelIdStr;
                    if (startingPath.equals("items")) {
                        modelIdStr = modelPath.substring(5);
                    } else {
                        modelIdStr = modelPath.substring(11);
                    }
                    if (modelIdStr.startsWith("/")) modelIdStr = modelIdStr.substring(1);
                    if (modelIdStr.isEmpty()) continue;

                    class_2960 modelId = class_2960.method_60655(resourceId.method_12836(), modelIdStr);

                    // Обрабатываем КАЖДЫЙ ресурс из каждого пака
                    for (class_3298 resource : entry.getValue()) {
                        boolean isRenamedModelFile = false;

                        try (InputStream is = resource.method_14482();
                             InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {

                            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

                            if (root.has("model") && root.get("model").isJsonObject()) {
                                JsonObject modelObj = root.getAsJsonObject("model");

                                if (modelObj.has("type") && modelObj.get("type").getAsString().endsWith("select") &&
                                        modelObj.has("component") && modelObj.get("component").getAsString().endsWith("custom_name") &&
                                        modelObj.has("cases")) {

                                    isRenamedModelFile = true;
                                    class_2960 baseItemId = class_2960.method_60655(resourceId.method_12836(), modelIdStr);
                                    class_1792 baseItem = class_7923.field_41178.method_63535(baseItemId);

                                    if (baseItem != class_1802.field_8162) {
                                        JsonArray cases = modelObj.getAsJsonArray("cases");
                                        for (JsonElement caseEl : cases) {
                                            if (!caseEl.isJsonObject()) continue;
                                            JsonObject caseObj = caseEl.getAsJsonObject();

                                            if (caseObj.has("when")) {
                                                JsonElement whenEl = caseObj.get("when");
                                                List<String> allNames = new ArrayList<>();

                                                if (whenEl.isJsonArray()) {
                                                    for (JsonElement e : whenEl.getAsJsonArray()) {
                                                        allNames.add(e.getAsString());
                                                    }
                                                } else if (whenEl.isJsonPrimitive()) {
                                                    allNames.add(whenEl.getAsString());
                                                }

                                                if (!allNames.isEmpty()) {
                                                    String primaryName = allNames.get(0);

                                                    // Уникальный ключ теперь включает имя пака — теперь все паки видны
                                                    String uniqueKey = resource.method_14480() + ":" + baseItemId + ":" + primaryName;

                                                    if (SEEN_RENAMED.add(uniqueKey)) {
                                                        class_1799 renamedStack = new class_1799(baseItem);

                                                        class_2499 nameList = new class_2499();
                                                        for (String name : allNames) {
                                                            nameList.add(class_2519.method_23256(name));
                                                        }
                                                        class_2487 data = new class_2487();
                                                        data.method_10566("alternative_names", nameList);

                                                        // ★ ИМЯ ПАКА ★
                                                        String packId = resource.method_14480();
                                                        String packName = packId.replace("file/", "").replace(".zip", "");
                                                        data.method_10582("pack_name", packName);

                                                        renamedStack.method_57379(class_9334.field_49628, class_9279.method_57456(data));
                                                        renamedStack.method_57379(class_9334.field_49631, class_2561.method_43470(primaryName));

                                                        LOADED_RENAMED_MODELS.add(renamedStack);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (Exception ignored) {
                        }

                        if (isRenamedModelFile) continue;

                        // Обычные модели (paper)
                        if (resourceId.method_12836().equals("minecraft")) continue;
                        if (startingPath.equals("models/item") && !packsWithItems.contains(resource.method_14480())) continue;

                        if (!SEEN_MODELS.add(modelId)) continue;

                        String fileName = modelId.method_12832().substring(modelId.method_12832().lastIndexOf('/') + 1)
                                .replace('_', ' ');

                        class_1799 stack = new class_1799(class_1802.field_8407);
                        stack.method_57379(class_9334.field_54199, modelId);
                        stack.method_57379(class_9334.field_49631,
                                class_2561.method_43470(fileName).method_27694(style -> style.method_10978(false)));

                        LOADED_MODELS.add(stack);
                    }
                }
            }
        });
    }
}