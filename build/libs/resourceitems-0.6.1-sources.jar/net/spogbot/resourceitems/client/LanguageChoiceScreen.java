package net.spogbot.resourceitems.client;

import java.util.function.Consumer;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_490;

public class LanguageChoiceScreen extends class_437 {
    private final class_437 parent;
    private final NameSelectionScreen.NameGroup group;
    private final Consumer<String> onSelect;

    // 0: Основная рука, 1: Вторая рука, 2: Голова
    private int renderMode = 0;

    public LanguageChoiceScreen(class_437 parent, NameSelectionScreen.NameGroup group, Consumer<String> onSelect) {
        super(class_2561.method_43471("screen.resourceitems.language_choice.title"));
        this.parent = parent;
        this.group = group;
        this.onSelect = onSelect;
    }

    @Override
    protected void method_25426() {
        int y = 60;
        // Центральные кнопки
        for (String name : group.names()) {
            this.method_37063(class_4185.method_46430(class_2561.method_43470(name), btn -> {
                if (this.field_22787 != null && parent instanceof NameSelectionScreen ns) {
                    this.field_22787.method_1507(ns.parent);
                }
                onSelect.accept(name);
            }).method_46434(this.field_22789 / 2 - 100, y, 200, 20).method_46431());
            y += 30;
        }

        // Вычисляем позицию кнопки слота: посередине между левым краем (40) и кнопкой "Back"
        int left = 40;
        int right = this.field_22789 / 2 - 50 - 20; // правый край — перед "Back" с отступом 20
        int buttonCenter = (left + right) / 2;
        int slotX = buttonCenter - 80; // центрируем кнопку шириной 160

        this.method_37063(class_4185.method_46430(getSlotText(), btn -> {
            renderMode = (renderMode + 1) % 3;
            btn.method_25355(getSlotText());
        }).method_46434(slotX, this.field_22790 - 35, 160, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.back"), b -> this.field_22787.method_1507(parent))
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 35, 100, 20)
                .method_46431());
    }

    private class_2561 getSlotText() {
        return switch (renderMode) {
            case 0 -> class_2561.method_43471("gui.choose.hand");
            case 1 -> class_2561.method_43471("gui.choose.offhand");
            default -> class_2561.method_43471("gui.choose.head");
        };
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        if (this.field_22787 != null && this.field_22787.field_1724 != null) {
            // Вычисляем позицию модельки: четко над кнопкой слота, центрирована
            int left = 40;
            int right = this.field_22789 / 2 - 50 - 20;
            int buttonCenter = (left + right) / 2;
            int boxWidth = 160; // ширина бокса как у кнопки
            int boxX1 = buttonCenter - boxWidth / 2;
            int boxX2 = buttonCenter + boxWidth / 2;
            int boxY1 = 40;
            int boxY2 = this.field_22790 - 60; // над кнопкой с отступом

            int entitySize = this.field_22790 / 6;

            class_1799 mainHand = this.field_22787.field_1724.method_6047();
            class_1799 offHand = this.field_22787.field_1724.method_6079();
            class_1799 head = this.field_22787.field_1724.method_6118(class_1304.field_6169);

            clearPlayerSlots();
            switch (renderMode) {
                case 0 -> this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5808, group.icon());
                case 1 -> this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5810, group.icon());
                case 2 -> this.field_22787.field_1724.method_5673(class_1304.field_6169, group.icon());
            }

            class_490.method_2486(
                    context,
                    boxX1, boxY1,
                    boxX2, boxY2,
                    entitySize,
                    0.0625f,
                    mouseX - (float)(boxX1 + boxX2) / 2.0f,
                    mouseY - (float)(boxY1 + boxY2) / 2.0f + 235,
                    this.field_22787.field_1724
            );

            this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5808, mainHand);
            this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5810, offHand);
            this.field_22787.field_1724.method_5673(class_1304.field_6169, head);
        }
    }

    private void clearPlayerSlots() {
        if (this.field_22787.field_1724 == null) return;
        this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5808, class_1799.field_8037);
        this.field_22787.field_1724.method_6122(net.minecraft.class_1268.field_5810, class_1799.field_8037);
        this.field_22787.field_1724.method_5673(class_1304.field_6169, class_1799.field_8037);
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}