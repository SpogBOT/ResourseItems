package net.spogbot.resourceitems.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_471;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.spogbot.resourceitems.mixin.AnvilScreenAccessor;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NameSelectionScreen extends class_437 {
    public final class_437 parent;
    private final class_1799 targetItem;

    private final List<NameGroup> groups = new ArrayList<>();
    private final List<NameGroup> filteredGroups = new ArrayList<>();
    private final List<class_4185> optionButtons = new ArrayList<>();
    private final List<class_4185> starButtons = new ArrayList<>();

    // === ФИЛЬТР ПО РЕСУРСПАКАМ ===
    private String currentPackFilter = "ALL";
    private List<String> sortedUniquePacks = new ArrayList<>();

    private class_4185 filterLeftButton;
    private class_4185 filterCenterButton;
    private class_4185 filterRightButton;

    // Глобальное избранное
    private static final Set<String> FAVORITE_NAMES = new HashSet<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FAVORITES_FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("resourceitems/favorites.json");

    static {
        loadFavorites();
    }

    private static void loadFavorites() {
        if (!Files.exists(FAVORITES_FILE)) {
            saveFavorites();
            return;
        }
        try (Reader reader = Files.newBufferedReader(FAVORITES_FILE)) {
            Type type = new TypeToken<Set<String>>() {}.getType();
            Set<String> loaded = GSON.fromJson(reader, type);
            if (loaded != null) FAVORITE_NAMES.addAll(loaded);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void saveFavorites() {
        try {
            Files.createDirectories(FAVORITES_FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FAVORITES_FILE)) {
                GSON.toJson(FAVORITE_NAMES, writer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class_342 searchField;
    private String searchQuery = "";

    private int cycleTimer = 0;
    private int scrollOffset = 0;
    private int maxScroll = 0;

    private static final int BUTTON_HEIGHT = 25;
    private static final int TOP_MARGIN = 70;
    private static final int BOTTOM_MARGIN = 90; // место под две строки кнопок
    private static final int SCROLLBAR_WIDTH = 6;
    private static final int SCROLLBAR_COLOR_TRACK = 0xFF808080;
    private static final int SCROLLBAR_COLOR_THUMB = 0xFFC0C0C0;

    private boolean isDraggingScrollbar = false;

    public static record NameGroup(class_1799 icon, List<String> names, String resourcePackName) {}

    public NameSelectionScreen(class_437 parent, class_1799 targetItem) {
        super(class_2561.method_43471("screen.resourceitems.item_choice.title"));
        this.parent = parent;
        this.targetItem = targetItem;

        for (class_1799 stack : ResourseitemsClient.LOADED_RENAMED_MODELS) {
            if (stack.method_7909() == targetItem.method_7909()) {
                List<String> names = getNamesForStack(stack);
                if (!names.isEmpty()) {
                    String pack = getResourcePackForStack(stack);
                    groups.add(new NameGroup(stack.method_7972(), List.copyOf(names), pack));
                }
            }
        }

        collectUniquePacks();
        filterGroups();
    }

    private void collectUniquePacks() {
        Set<String> packSet = new HashSet<>();
        for (NameGroup g : groups) {
            packSet.add(g.resourcePackName());
        }
        sortedUniquePacks = new ArrayList<>(packSet);
        sortedUniquePacks.sort(String.CASE_INSENSITIVE_ORDER);
    }

    private List<String> getNamesForStack(class_1799 stack) {
        class_9279 component = stack.method_58694(class_9334.field_49628);
        if (component == null || component.method_57458()) {
            return List.of(stack.method_7964().getString());
        }
        class_2487 nbt = component.method_57461();
        class_2520 element = nbt.method_10580("alternative_names");
        if (element instanceof class_2499 list) {
            List<String> names = new ArrayList<>(list.size());
            for (class_2520 e : list) {
                names.add(e.method_68658().orElse(""));
            }
            if (!names.isEmpty()) return names;
        }
        return List.of(stack.method_7964().getString());
    }

    private String getResourcePackForStack(class_1799 stack) {
        class_9279 component = stack.method_58694(class_9334.field_49628);
        if (component != null && !component.method_57458()) {
            class_2487 nbt = component.method_57461();
            if (nbt.method_10545("pack_name")) {
                String pack = String.valueOf(nbt.method_10558("pack_name"));
                if (pack.startsWith("Optional[")) {
                    pack = pack.substring(9, pack.length() - 1);
                }
                return pack;
            }
        }
        return class_2561.method_43471("gui.resourceitems.unknown_pack").getString();
    }

    private static boolean isGroupFavorite(NameGroup group) {
        return group.names().stream().anyMatch(FAVORITE_NAMES::contains);
    }

    private void filterGroups() {
        filteredGroups.clear();
        String query = searchQuery.trim().toLowerCase();

        for (NameGroup group : groups) {
            if (!currentPackFilter.equals("ALL") && !group.resourcePackName().equals(currentPackFilter)) continue;
            boolean matches = query.isEmpty() ||
                    group.names().stream().anyMatch(n -> n.toLowerCase().contains(query));
            if (matches) {
                filteredGroups.add(group);
            }
        }

        filteredGroups.sort(Comparator.comparing(NameSelectionScreen::isGroupFavorite).reversed()
                .thenComparing(NameGroup::resourcePackName, String.CASE_INSENSITIVE_ORDER));
    }

    private void cyclePackFilter(boolean forward) {
        if (sortedUniquePacks.isEmpty()) return;

        if (currentPackFilter.equals("ALL")) {
            currentPackFilter = forward ? sortedUniquePacks.get(0) : sortedUniquePacks.get(sortedUniquePacks.size() - 1);
        } else {
            int idx = sortedUniquePacks.indexOf(currentPackFilter);
            if (idx == -1) {
                currentPackFilter = "ALL";
                return;
            }
            currentPackFilter = forward
                    ? (idx + 1 < sortedUniquePacks.size() ? sortedUniquePacks.get(idx + 1) : "ALL")
                    : (idx - 1 >= 0 ? sortedUniquePacks.get(idx - 1) : "ALL");
        }

        scrollOffset = 0;
        method_37067();
        method_25426();
    }

    @Override
    protected void method_25426() {
        optionButtons.clear();
        starButtons.clear();

        searchField = new class_342(this.field_22793,
                this.field_22789 / 2 - 100, 35, 200, 20,
                class_2561.method_43471("gui.resourceitems.name_selection.search"));
        searchField.method_1880(64);
        searchField.method_1852(searchQuery);
        searchField.method_47404(class_2561.method_43471("gui.resourceitems.name_selection.search.placeholder"));
        searchField.method_1863(this::onSearchChanged);
        this.method_37063(searchField);

        filterGroups();

        int visibleArea = this.field_22790 - TOP_MARGIN - BOTTOM_MARGIN;
        int totalHeight = filteredGroups.size() * BUTTON_HEIGHT;
        this.maxScroll = Math.max(0, totalHeight - visibleArea);

        int index = 0;
        for (NameGroup group : filteredGroups) {
            int y = TOP_MARGIN + index * BUTTON_HEIGHT - scrollOffset;

            class_4185 button = class_4185.method_46430(
                    class_2561.method_43470(group.names().get(0)),
                    btn -> openLanguageMenu(group)
            ).method_46434(this.field_22789 / 2 - 100, y, 190, 20).method_46431();

            button.field_22764 = y >= TOP_MARGIN - BUTTON_HEIGHT && y <= this.field_22790 - BOTTOM_MARGIN;
            this.method_37063(button);
            optionButtons.add(button);

            class_4185 starBtn = class_4185.method_46430(
                    getStarText(group),
                    btn -> toggleFavorite(group)
            ).method_46434(this.field_22789 / 2 + 96, y, 24, 20).method_46431();

            starBtn.field_22764 = button.field_22764;
            this.method_37063(starBtn);
            starButtons.add(starBtn);

            index++;
        }

        // ==================== КНОПКИ ФИЛЬТРА ПО ЦЕНТРУ ====================
        int filterY = this.field_22790 - 60;
        int centerX = this.field_22789 / 2;

        filterLeftButton = class_4185.method_46430(class_2561.method_43470("◀"), btn -> cyclePackFilter(false))
                .method_46434(centerX - 105, filterY, 30, 20).method_46431();
        this.method_37063(filterLeftButton);

        filterCenterButton = class_4185.method_46430(
                currentPackFilter.equals("ALL") ? class_2561.method_43471("gui.resourceitems.all_packs") : class_2561.method_43470(currentPackFilter),
                btn -> {
                    currentPackFilter = "ALL";
                    scrollOffset = 0;
                    method_37067();
                    method_25426();
                }
        ).method_46434(centerX - 70, filterY, 140, 20).method_46431();
        this.method_37063(filterCenterButton);

        filterRightButton = class_4185.method_46430(class_2561.method_43470("▶"), btn -> cyclePackFilter(true))
                .method_46434(centerX + 75, filterY, 30, 20).method_46431();
        this.method_37063(filterRightButton);

        // ==================== КНОПКА BACK — СТРОГО ПО ЦЕНТРУ ====================
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.back"), b -> this.method_25419())
                .method_46434(centerX - 50, this.field_22790 - 35, 100, 20)
                .method_46431());

        updateButtonTexts();
        searchField.method_25365(true);
    }

    private class_2561 getStarText(NameGroup group) {
        boolean isFav = isGroupFavorite(group);
        return class_2561.method_43470(isFav ? "★" : "☆")
                .method_27694(style -> style.method_36139(isFav ? 0xFFCC00 : 0x777777));
    }

    @Override
    public void method_25393() {
        super.method_25393();
        cycleTimer++;
        if (cycleTimer % 60 == 0) {
            updateButtonTexts();
        }
    }

    private void updateButtonTexts() {
        for (int i = 0; i < Math.min(optionButtons.size(), filteredGroups.size()); i++) {
            NameGroup group = filteredGroups.get(i);
            class_4185 btn = optionButtons.get(i);

            if (group.names().size() > 1) {
                int idx = (cycleTimer / 60) % group.names().size();
                btn.method_25355(class_2561.method_43470(group.names().get(idx)));
            }
        }
    }

    private void toggleFavorite(NameGroup group) {
        boolean currentlyFavorite = isGroupFavorite(group);

        if (currentlyFavorite) {
            FAVORITE_NAMES.removeAll(group.names());
        } else {
            FAVORITE_NAMES.addAll(group.names());
        }

        saveFavorites();
        method_37067();
        method_25426();
    }

    private void onSearchChanged(String newText) {
        searchQuery = newText;
        scrollOffset = 0;
        method_37067();
        method_25426();
    }

    private void openLanguageMenu(NameGroup group) {
        this.field_22787.method_1507(new LanguageChoiceScreen(this, group, this::applyNameToAnvil));
    }

    private void applyNameToAnvil(String name) {
        if (parent instanceof class_471 anvilScreen) {
            AnvilScreenAccessor accessor = (AnvilScreenAccessor) anvilScreen;
            class_342 nameField = accessor.getNameField();
            if (nameField != null) {
                nameField.method_1852(name);
                accessor.invokeOnRenamed(name);
            }
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount)) return true;
        scrollOffset = (int) (scrollOffset - verticalAmount * 10);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
        method_37067();
        method_25426();
        return true;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (maxScroll > 0 && click.method_74245() == 0) {
            int scrollbarX = this.field_22789 - SCROLLBAR_WIDTH - 5;
            int scrollbarY = TOP_MARGIN;
            int scrollbarHeight = this.field_22790 - TOP_MARGIN - BOTTOM_MARGIN;
            if (click.comp_4798() >= scrollbarX && click.comp_4798() <= scrollbarX + SCROLLBAR_WIDTH &&
                    click.comp_4799() >= scrollbarY && click.comp_4799() <= scrollbarY + scrollbarHeight) {
                this.isDraggingScrollbar = true;
                updateScrollFromMouse(click.comp_4799());
                return true;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (this.isDraggingScrollbar) {
            updateScrollFromMouse(click.comp_4799());
            return true;
        }
        return super.method_25403(click, offsetX, offsetY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == 0 && this.isDraggingScrollbar) {
            this.isDraggingScrollbar = false;
            return true;
        }
        return super.method_25406(click);
    }

    private void updateScrollFromMouse(double mouseY) {
        int scrollbarHeight = this.field_22790 - TOP_MARGIN - BOTTOM_MARGIN;
        if (scrollbarHeight <= 0) return;

        int totalHeight = maxScroll + scrollbarHeight;
        int thumbHeight = Math.max(20, (scrollbarHeight * scrollbarHeight) / totalHeight);
        double trackDraggableHeight = scrollbarHeight - thumbHeight;
        if (trackDraggableHeight <= 0) return;

        double thumbCenterOffset = mouseY - TOP_MARGIN - (thumbHeight / 2.0);
        double scrollFraction = thumbCenterOffset / trackDraggableHeight;
        scrollFraction = Math.max(0.0, Math.min(1.0, scrollFraction));

        scrollOffset = (int) (scrollFraction * maxScroll);
        method_37067();
        method_25426();
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 0xFFFFFF);

        int index = 0;
        for (NameGroup group : filteredGroups) {
            int y = TOP_MARGIN + index * BUTTON_HEIGHT - scrollOffset;
            if (y >= TOP_MARGIN - BUTTON_HEIGHT && y <= this.field_22790 - BOTTOM_MARGIN) {
                int buttonX = this.field_22789 / 2 - 100;
                context.method_51427(group.icon(), buttonX - 25, y + 2);
            }
            index++;
        }

        if (maxScroll > 0) {
            int scrollbarX = this.field_22789 - SCROLLBAR_WIDTH - 5;
            int scrollbarY = TOP_MARGIN;
            int scrollbarHeight = this.field_22790 - TOP_MARGIN - BOTTOM_MARGIN;

            context.method_25294(scrollbarX, scrollbarY, scrollbarX + SCROLLBAR_WIDTH, scrollbarY + scrollbarHeight, SCROLLBAR_COLOR_TRACK);

            int visibleArea = scrollbarHeight;
            int totalHeight = maxScroll + visibleArea;
            int thumbHeight = Math.max(20, (visibleArea * visibleArea) / totalHeight);
            int thumbY = scrollbarY + (scrollOffset * (scrollbarHeight - thumbHeight)) / maxScroll;

            context.method_25294(scrollbarX, thumbY, scrollbarX + SCROLLBAR_WIDTH, thumbY + thumbHeight, SCROLLBAR_COLOR_THUMB);
        }

        // Tooltip при ховере
        for (int i = 0; i < optionButtons.size(); i++) {
            class_4185 button = optionButtons.get(i);
            if (button.method_25405(mouseX, mouseY)) {
                NameGroup group = filteredGroups.get(i);
                List<class_2561> tooltipLines = new ArrayList<>();

                int idx = group.names().size() > 1 ? (cycleTimer / 60) % group.names().size() : 0;
                tooltipLines.add(class_2561.method_43470(group.names().get(idx)).method_27692(class_124.field_1067));

                if (group.names().size() > 1) {
                    tooltipLines.add(class_2561.method_43470(""));
                    tooltipLines.add(class_2561.method_43471("gui.resourceitems.alternative_names").method_27692(class_124.field_1080));
                    int maxNamesToShow = 5;
                    for (int n = 0; n < Math.min(group.names().size(), maxNamesToShow); n++) {
                        tooltipLines.add(class_2561.method_43470(" • " + group.names().get(n)).method_27692(class_124.field_1068));
                    }
                    if (group.names().size() > maxNamesToShow) {
                        tooltipLines.add(class_2561.method_43470(" • ... и ещё " + (group.names().size() - maxNamesToShow))
                                .method_27692(class_124.field_1080));
                    }
                }

                tooltipLines.add(class_2561.method_43470(""));
                tooltipLines.add(class_2561.method_43471("gui.resourceitems.from_pack")
                        .method_27693(": ")
                        .method_10852(class_2561.method_43470(group.resourcePackName()).method_27692(class_124.field_1054)));

                List<class_1799> compatibleItems = getCompatibleItemsForGroup(group);
                boolean hasCompatible = !compatibleItems.isEmpty();
                if (hasCompatible) {
                    tooltipLines.add(class_2561.method_43470(""));
                    tooltipLines.add(class_2561.method_43471("gui.resourceitems.compatible_with").method_27692(class_124.field_1080));
                }

                int maxTextWidth = tooltipLines.stream()
                        .mapToInt(field_22793::method_27525)
                        .max().orElse(0);

                int textHeight = tooltipLines.size() * field_22793.field_2000 + 12;

                int iconsHeight = 0;
                int iconsWidth = 0;
                if (hasCompatible) {
                    int iconsPerRow = 8;
                    int numRows = (int) Math.ceil(compatibleItems.size() / (double) iconsPerRow);
                    iconsHeight = numRows * 18 + 8;
                    iconsWidth = Math.min(compatibleItems.size(), iconsPerRow) * 18;
                }

                int totalWidth = Math.max(maxTextWidth, iconsWidth) + 20;
                int totalHeight = textHeight + iconsHeight;

                int tipX = mouseX + 12;
                int tipY = mouseY - 12;
                if (tipX + totalWidth > this.field_22789) tipX = mouseX - totalWidth - 12;
                if (tipY + totalHeight > this.field_22790) tipY = mouseY - totalHeight + 12;
                if (tipY < 4) tipY = 4;

                context.method_25294(tipX - 3, tipY - 3, tipX + totalWidth + 3, tipY + totalHeight + 3, 0xF0100010);
                context.method_25296(tipX - 3, tipY - 4, tipX + totalWidth + 3, tipY - 3, 0x505000FF, 0x502800FF);
                context.method_25296(tipX - 3, tipY + totalHeight + 2, tipX + totalWidth + 3, tipY + totalHeight + 3, 0x502800FF, 0x30000000);

                int textY = tipY + 4;
                for (class_2561 line : tooltipLines) {
                    context.method_27535(field_22793, line, tipX + 6, textY, 0xFFFFFFFF);
                    textY += field_22793.field_2000;
                }

                if (hasCompatible) {
                    int iconY = tipY + textHeight + 2;
                    int iconX = tipX + 6;
                    int count = 0;
                    for (class_1799 item : compatibleItems) {
                        context.method_51427(item, iconX, iconY);
                        iconX += 18;
                        count++;
                        if (count % 8 == 0) {
                            iconX = tipX + 6;
                            iconY += 18;
                        }
                    }
                }

                break;
            }
        }
    }

    private List<class_1799> getCompatibleItemsForGroup(NameGroup group) {
        Set<class_1792> uniqueItems = new HashSet<>();
        List<class_1799> compatible = new ArrayList<>();

        class_1792 currentItem = targetItem.method_7909();
        compatible.add(new class_1799(currentItem));
        uniqueItems.add(currentItem);

        for (String name : group.names()) {
            for (class_1799 model : ResourseitemsClient.LOADED_RENAMED_MODELS) {
                class_1792 itemType = model.method_7909();
                if (uniqueItems.contains(itemType)) continue;

                if (getNamesForStack(model).contains(name)) {
                    compatible.add(new class_1799(itemType));
                    uniqueItems.add(itemType);

                    if (compatible.size() >= 12) return compatible;
                }
            }
        }
        return compatible;
    }
}